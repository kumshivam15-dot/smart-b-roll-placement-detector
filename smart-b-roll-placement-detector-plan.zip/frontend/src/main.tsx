import { Check, Film, RotateCcw, X } from "lucide-react";
import { StrictMode, useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";

type TranscriptSegment = {
  id: string;
  start: number;
  end: number;
  text: string;
};

type Transcript = {
  title: string;
  duration: number;
  segments: TranscriptSegment[];
};

type Placement = {
  segment_id: string;
  start: number;
  end: number;
  reason: string;
  score?: number;
};

const API_URL = "http://127.0.0.1:8000/detect";

function App() {
  const [transcript, setTranscript] = useState<Transcript | null>(null);
  const [placements, setPlacements] = useState<Placement[]>([]);
  const [rejectedIds, setRejectedIds] = useState<Set<string>>(new Set());
  const [status, setStatus] = useState("Loading transcript...");

  useEffect(() => {
    async function loadAndDetect() {
      try {
        const transcriptResponse = await fetch("/transcript.json");
        const nextTranscript = (await transcriptResponse.json()) as Transcript;
        setTranscript(nextTranscript);
        setStatus("Detecting B-roll placements...");

        const detectResponse = await fetch(API_URL, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(nextTranscript),
        });

        if (!detectResponse.ok) {
          throw new Error(`Detector returned ${detectResponse.status}`);
        }

        setPlacements((await detectResponse.json()) as Placement[]);
        setStatus("Ready");
      } catch (error) {
        setStatus(error instanceof Error ? error.message : "Unable to run detector");
      }
    }

    void loadAndDetect();
  }, []);

  const placementBySegment = useMemo(() => {
    return new Map(placements.map((placement) => [placement.segment_id, placement]));
  }, [placements]);

  const acceptedPlacements = placements.filter((placement) => !rejectedIds.has(placement.segment_id));
  const acceptedCoverage = acceptedPlacements.reduce(
    (total, placement) => total + placement.end - placement.start,
    0,
  );

  function toggleRejected(segmentId: string) {
    setRejectedIds((current) => {
      const next = new Set(current);
      if (next.has(segmentId)) {
        next.delete(segmentId);
      } else {
        next.add(segmentId);
      }
      return next;
    });
  }

  function resetRejected() {
    setRejectedIds(new Set());
  }

  return (
    <main className="shell">
      <section className="topbar">
        <div>
          <p className="eyebrow">Rule-based detector</p>
          <h1>{transcript?.title ?? "Smart B-roll Detector"}</h1>
        </div>
        <div className="statusPanel" aria-label="accepted suggestion summary">
          <span>{status}</span>
          <strong>{acceptedPlacements.length} accepted</strong>
          <strong>{acceptedCoverage.toFixed(1)}s coverage</strong>
        </div>
      </section>

      <section className="workspace" aria-label="transcript timeline">
        <div className="timelineHeader">
          <div>
            <h2>Transcript timeline</h2>
            <p>Suggested segments are snapped to source transcript boundaries.</p>
          </div>
          <button className="iconButton" type="button" onClick={resetRejected} aria-label="restore all suggestions">
            <RotateCcw size={18} />
          </button>
        </div>

        <ol className="timeline">
          {transcript?.segments.map((segment) => {
            const placement = placementBySegment.get(segment.id);
            const rejected = rejectedIds.has(segment.id);
            const suggested = Boolean(placement);
            return (
              <li
                key={segment.id}
                className={["timelineRow", suggested ? "suggested" : "", rejected ? "rejected" : ""].join(" ")}
              >
                <div className="timeRail">
                  <span>{formatTime(segment.start)}</span>
                  <span>{formatTime(segment.end)}</span>
                </div>
                <div className="segmentBody">
                  <p>{segment.text}</p>
                  {placement ? (
                    <div className="reason">
                      <Film size={16} />
                      <span>{placement.reason} Score {placement.score}.</span>
                    </div>
                  ) : null}
                </div>
                {placement ? (
                  <button
                    className="decisionButton"
                    type="button"
                    onClick={() => toggleRejected(segment.id)}
                    aria-label={rejected ? "accept suggestion" : "reject suggestion"}
                  >
                    {rejected ? <Check size={18} /> : <X size={18} />}
                    <span>{rejected ? "Accept" : "Reject"}</span>
                  </button>
                ) : (
                  <span className="notSuggested">No B-roll</span>
                )}
              </li>
            );
          })}
        </ol>
      </section>
    </main>
  );
}

function formatTime(seconds: number) {
  return `${seconds.toFixed(seconds % 1 === 0 ? 0 : 1)}s`;
}

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
